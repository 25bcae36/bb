
const express = require("express");

const cors = require("cors");
const mysql = require("mysql2");

const app = express();
const PORT = 3000;
console.log("SERVER FILE:", __filename);

app.use(cors());
app.use((req, res, next) => {
    console.log("REQUEST:", req.method, req.url);
    next();
});
app.use(express.json());

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "borrowbox"
});


db.connect((err) => {
    if (err) {
        console.error("Database connection failed:", err);
        return;
    }

    console.log("Connected to BorrowBox database!");
});


app.get("/", (req, res) => {
    res.send("BorrowBox backend is running!");
});

app.get("/api/test-db", (req, res) => {
    db.query("SHOW TABLES", (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json({
            success: true,
            tables: results
        });
    });
});

app.get("/api/items", (req, res) => {
    db.query("SELECT * FROM items", (err, results) => {
        if (err) {
            return res.status(500).json({
                success: false,
                error: err.message
            });
        }

        res.json({
            success: true,
            items: results
        });
    });
});


app.post("/api/items/test", (req, res) => {
    const item = {
        id: "test-item-001",
        ownerId: "test@borrowbox.com",
        name: "Test Book",
        category: "Books",
        description: "Testing BorrowBox database",
        condition: "Good",
        location: "Library",
        availability: "Available"
    };

    const sql = `
        INSERT INTO items
        (id, ownerId, name, category, description, \`condition\`,
         location, availability)
        
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)

    `;

    const values = [
        item.id,
        item.ownerId,
        item.name,
        item.category,
        item.description,
        item.condition,
        item.location,
        item.availability
    ];

    db.query(sql, values, (err, result) => {
        if (err) {
            return res.status(500).json({
                success: false,
                error: err.message
            });
        }

        res.status(201).json({
            success: true,
            message: "Test item saved to MySQL!",
            itemId: item.id
        });
    });
});


app.get("/api/check-users", (req, res) => {
    db.query("DESCRIBE users", (err, results) => {
        if (err) {
            return res.status(500).json({
                success: false,
                error: err.message
            });
        }

        res.json({
            success: true,
            columns: results.map(row => ({
                name: row.Field,
                type: row.Type,
                nullable: row.Null,
                key: row.Key,
                default: row.Default
            }))
        });
    });
});



app.post("/api/register-user", (req, res) => {
    const { email, name } = req.body;

    if (!email || !name) {
        return res.status(400).json({
            success: false,
            error: "Email and name are required."
        });
    }

    db.query(
        "INSERT INTO users (email, name) VALUES (?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name)",
        [email, name],
        (err) => {
            if (err) {
                return res.status(500).json({
                    success: false,
                    error: err.message
                });
            }

            res.json({
                success: true,
                message: "User is registered in the database."
            });
        }
    );
});

console.log("Registering POST /api/items");
app.post("/api/items", (req, res) => {
    console.log("POST /api/items reached");
    console.log("Submitted ownerId:", req.body.ownerId);
    const {
        ownerId,
        name,
        category,
        description,
        condition,
        location,
        availability,
        availableFrom,
        availableUntil
    } = req.body;

    // Check the required fields
    if (!ownerId || !name || !category || !condition || !location) {
        return res.status(400).json({
            success: false,
            error: "Please provide all required item details."
        });
    }

    const item = {
        id: "it" + Date.now().toString(36),
        ownerId,
        name,
        category,
        description: description || "",
        condition,
        location,
        availability: availability || "Available"
    };

   
    const sql = `
        INSERT INTO items
        (id, ownerId, name, category, description, \`condition\`,
         location, availability)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;


    const values = [
        item.id,
        item.ownerId,
        item.name,
        item.category,
        item.description,
        item.condition,
        item.location,
        item.availability
    ];

    db.query(sql, values, (err) => {
        if (err) {
            console.error("Failed to save item:", err.message);

            return res.status(500).json({
                success: false,
                error: err.message
            });
        }

        res.status(201).json({
            success: true,
            message: "Item saved successfully!",
            item
        });
    });
});

app.listen(PORT, () => {
    console.log(`BorrowBox server running at http://localhost:${PORT}`);
});
